
local order = {};
local games = {};
local other = {};

local function append_url(line, idx)
	if(not games[idx])then
		order[#order + 1] = idx;
		games[idx] = {line};
	else
		table.insert(games[idx],line);
	end;
end;

for line in io.lines("GAMES.lua")do
	if(not line:match("%[%d+"))then
		other[#other + 1] = line;
	else
		if(line:sub(-1)~=',')then line = line..','end;
		append_url(line, line:match("1201for/(.+)/main"));
	end;
end;

do	-- sort each game w.r.t gameId
	local function sort(a,b)
		return tonumber(a:match("%d+")) < tonumber(b:match("%d+"));
	end;
	
	for idx,tbl in next,games do
		table.sort(tbl, sort);
		games[idx] = table.concat(tbl, '\n');
	end;
end;

local fmt = '';
for idx,key in ipairs(order)do
	if(idx==#order)then
		fmt = fmt..games[key];
	else
		fmt = fmt..games[key]..'\n';
	end;
end;

table.insert(other,2,fmt);
io.open("TEST.lua",'w'):write(table.concat(other,'\n')):close();
